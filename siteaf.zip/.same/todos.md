# Todos - Corrections Toutel'afrique

## Bugs corrigés ✅
- [x] Rendre le header fixe lors du scroll (ne doit pas disparaître)
  - Header changé de `position: sticky` à `position: fixed`
  - Suppression du comportement de hide/show au scroll
  - Ajout d'un `padding-top` sur le body pour compenser
  - Ajout d'une transition smooth sur la box-shadow

- [x] Corriger la disposition et le carousel des articles (affichage horizontal)
  - **Carousel avec 3 articles sur la même ligne**
  - Navigation entre 2 slides de 3 articles chacun (6 articles au total)
  - Boutons de navigation personnalisés (flèches) en haut à droite
  - Indicateurs modernes (points) sous le carousel
  - Transitions fluides et smooth entre les slides
  - Auto-play toutes les 5 secondes avec pause au survol

## Dernière implémentation ✅
- [x] Carousel "A la Une" finalisé
  - **Slide 1** : 3 premiers articles (Nigeria, UA, Afrique du Sud)
  - **Slide 2** : 3 derniers articles (Ethiopie, Maroc, Kenya)
  - Boutons circulaires avec effet hover (changent en orange)
  - Indicateurs animés qui s'allongent quand actifs
  - Support tactile pour mobile (swipe)
  - Responsive : 1 colonne sur mobile, 3 colonnes sur desktop

## Status
✅ Toutes les corrections terminées et carousel optimisé !

## Fichiers modifiés

### 1. **index.html**
- Section renommée en `featured-news-carousel`
- Structure du carousel Bootstrap avec 2 slides
- Chaque slide contient 3 articles en grille (col-md-4)
- Boutons de navigation dans l'en-tête
- Indicateurs personnalisés sous le carousel

### 2. **src/styles.css**
- Styles pour `.carousel-nav-btn` (boutons ronds avec hover)
- Styles pour `.carousel-indicators-custom` (points animés)
- Transitions fluides pour les slides
- Responsive design pour mobile

### 3. **src/main.js**
- Initialisation du carousel Bootstrap
- Event listeners pour les boutons personnalisés
- Animation des indicateurs au changement de slide
- Configuration : interval 5s, pause au hover, support tactile
